// app.js
// Appwrite Auth Setup

// Import Appwrite SDK
const { Client, Account } = Appwrite;

// Init Appwrite Client
const client = new Client()
    .setEndpoint('https://fra.cloud.appwrite.io/v1') // Replace with your endpoint
    .setProject('6891b44a001e1db78112'); // Replace with your project ID

const account = new Account(client);

// ------------------------
// Soft Notification Function
// ------------------------
function showNotification(message, type = "success") {
    let notif = document.createElement("div");
    notif.className = `soft-notification ${type}`;
    notif.textContent = message;
    document.body.appendChild(notif);

    setTimeout(() => {
        notif.classList.add("show");
    }, 10);

    setTimeout(() => {
        notif.classList.remove("show");
        setTimeout(() => notif.remove(), 300);
    }, 3000);
}

// ------------------------
// Register User
// ------------------------
async function registerUser(email, password, name) {
    try {
        await account.create('unique()', email, password, name);
        showNotification("✅ Registration successful! Redirecting to login...", "success");
        setTimeout(() => {
            window.location.href = "login.html";
        }, 2000);
    } catch (error) {
        console.error("Registration failed:", error);
        showNotification("❌ " + (error.message || "Registration failed. Try again."), "error");
    }
}

// ------------------------
// Login User
// ------------------------
async function loginUser(email, password) {
    try {
        await account.createEmailPasswordSession(email, password);
        showNotification("✅ Login successful!", "success");
        setTimeout(() => {
            window.location.href = "index.html";
        }, 2000);
    } catch (error) {
        console.error("Login failed:", error);
        showNotification("❌ " + (error.message || "Login failed. Try again."), "error");
    }
}

// ------------------------
// Check Auth Status
// ------------------------
async function checkAuth() {
    try {
        const user = await account.get();
        console.log("Logged in as:", user);
        return user;
    } catch (error) {
        console.log("Not logged in");
        return null;
    }
}

// ------------------------
// Logout
// ------------------------
async function logoutUser() {
    try {
        await account.deleteSession("current");
        showNotification("✅ Logged out successfully!", "success");
        setTimeout(() => {
            window.location.href = "login.html";
        }, 2000);
    } catch (error) {
        console.error("Logout failed:", error);
        showNotification("❌ Logout failed", "error");
    }
}

// ------------------------
// Hook up Register Form
// ------------------------
document.addEventListener("DOMContentLoaded", () => {
    const regForm = document.getElementById("registerForm");
    if (regForm) {
        regForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const email = document.querySelector("[name='email']").value.trim();
            const password = document.querySelector("[name='password']").value.trim();
            const name = document.querySelector("[name='name']").value.trim();
            registerUser(email, password, name);
        });
    }
});