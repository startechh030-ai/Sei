document.addEventListener("DOMContentLoaded", () => {
  const loader = document.getElementById("loader");
  setTimeout(() => {
    loader.classList.add("fade-out");
    setTimeout(() => loader.style.display = "none", 500);
  }, 70000); // Change to 3000 for 3 sec
});